---

layout: col-sidebar
title: An example subdir

---

# Just an example of a subdirectory using col-sidebar layout.  Requires an info.md file within the subdir.

